Firebase Deploy Instructions:
1. firebase login
2. firebase init hosting (public folder = build, SPA = yes)
3. firebase deploy